package it.polimi.tiw.Project.dao;

public class DocsDAO {

	
	//metodo per aggiungere documenti ad una cartella
	
	//metodo per ottenere tutti i documenti in una cartella
}
